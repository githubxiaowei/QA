from langconv import *
import jieba
jieba.load_userdict('dict/wiki_dict')

from time import time
stopWords = ['上','的','什么','什麼','是','大','第几',\
             '过','多少','多少次','？','哪','谁','哪里',\
            '哪个','哪种','哪位','哪座','指','和','呢','吗','有','没有','个','什么样','是不是','不是']

#页面号到页面路径的映射
def idx2file(id):
    fpath = 'pages/'+str(id>>16 & 255)+'/'+\
            str(id>>8 & 255)+'/'+str(id&255)
    return fpath
#对于查询语句，使用jieba分词将其拆分，用每一个分词查询映射表，如果映射表中有对应的条目，说明维基百科中有专门的页面对应到该分词，返回该页面的序号
def findDoc(query):
    keyList = []
    for word in jieba.cut_for_search(query):
        if(word not in stopWords):
            try:
                #print(word)
                keyList.extend(wiki_dict[word])
            except Exception as e:
                pass
    return keyList

#从返回的页面中逐句搜索，记录每一句话中包含查询语句的所有分词的数目，重复出现只按一次计算，作为该句子的得分，最后对得分排序
def findLine(query, minLen=20, maxReturn=5):
    s = []
    docList = findDoc(query)
    keywords = '.'.join(jieba.cut_for_search(query)).split('.')

    for docIdx in docList:
        with open(idx2file(docIdx),encoding='utf8') as f:
            for line in f.readlines():
                if(len(line) > minLen):
                    tf = {}
                    for word in jieba.cut_for_search(line):
                        if(word in keywords and word not in stopWords):
                            tf[word] = 1 
                    bingo = len(tf)
                    s.append(('位于page_'+str(docIdx)+'   '+line,bingo))
    #转化为繁体再查询一次
    query = Converter('zh-hant').convert(query)
    docList = findDoc(query)
    keywords = '.'.join(jieba.cut_for_search(query)).split('.')

    for docIdx in docList:
        with open(idx2file(docIdx),encoding='utf8') as f:
            for line in f.readlines():
                if(len(line) > minLen): #句子不能太短
                    tf = {}
                    for word in jieba.cut_for_search(line):
                        if(word in keywords and word not in stopWords):
                            tf[word] = 1 #出现就记为1
                    bingo = len(tf) #表示句子包含查询语句的分词的种数
                    s.append(('位于page_'+str(docIdx)+'   '+line,bingo))
    #对得分排序
    s = sorted(s,key=lambda x:x[1], reverse=1)
    return [item[0] for item in s[:maxReturn]]

#由于页面标题基本没有重复，所以建立标题到页面的映射表
title2idx = {}
id = 0
with open('titles',encoding='utf8') as f:
    for t in f.readlines():
        id += 1
        t = t.strip('\n')
        if(t not in title2idx):
            title2idx[t] = [id,]
        else:
            title2idx[t].append(id)
print('number of titles: {}'.format(len(title2idx)))
'''
#将标题中关于'Category', 'Wikipedia', 'MediaWiki', 'Template', 'File', 'Topic'等和知识内容无关的标题去掉
stop = ['Category','Wikipedia','MediaWiki','Template','File','Topic']
with open('wiki_dict','w',encoding='utf8') as fout:
    for line in title2idx:
        flag = 1
        for w in stop:
            if(w in line):
                flag = 0
        if(flag):
            fout.write(line+'\n')
'''
#将重复的标题对应的页面合并,得到wiki_dict
wiki_dict = {}
with open('wiki_dict',encoding='utf8') as fin:
    for line in fin.readlines():
        key = re.sub(r' .*','',line.strip('\n'))
        if(key not in wiki_dict):
            wiki_dict[key] = []
        wiki_dict[key].extend(title2idx[line.strip('\n')])
        
print('number of wikis: {}'.format(len(wiki_dict)))
'''
#将wiki_dict作为分词的词典
with open('dict/wiki_dict','w',encoding='utf8') as f:
    for key in wiki_dict:
        f.write(key+'\n')
'''
#测试集的8000个句子
questions = []
with open('test.txt',encoding='utf8') as fin:
    for line in fin.readlines():
        questions.append(line.split('\t')[0])

for idx in range(8000):
	q = questions[idx]
	try:
		print(q)
		start = time()
		result = findLine(q)
		#print(result)
		with open('test_ans/ans_{}.txt'.format(idx),'a',encoding='utf8') as f:
			for l in result:
				f.write(l+'\n')
		print('用时 {}s'.format(time()-start))
	except Exception as e:
		print(e)


